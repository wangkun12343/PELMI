Authors
=======

| Name            | Organization                       |
|:---------------:|:----------------------------------:|
| Zhi PING        | Synthetic Biology Platform of BGI-Research |
| Sha (Joe) ZHU   | Sensyne Health  	                       |
| Hao-Ling ZHANG  | Synthetic Biology Platform of BGI-Research |
